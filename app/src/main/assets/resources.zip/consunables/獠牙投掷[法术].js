jobject.road=2;
jobject.name="獠牙投掷[法术]";
jobject.icon=1;
jobject.explain="通过投掷野猪的獠牙进行攻击，每根獠牙造成40%攻击伤害";
jobject.applylv=1;
jobject.usetype=1;
jobject.buy_price=1;
jobject.price=1;
var obj = {
/*
使用
@space 背包空间
@initiator 使用者
@target 使用对象
@pall攻击管理器

*/
use:function(space, initiator, target, pall)
{
var flag = target.addSkill("獠牙投掷");
pall.getEvent().Message("已获得技能 "+pall.getGood().name, 17);

return flag;
}

}
var use=new ConsunablesUse(obj);
jobject.setUse(use);
