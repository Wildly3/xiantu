jobject.road=0;
jobject.name="灵泉水";
jobject.icon=2;
jobject.explain="采集自灵气浓郁灵池的泉水，恢复[100]生命值";
jobject.applylv=0;
jobject.buy_price=110;
jobject.price=55;
var obj = {
/*
使用
@space 背包空间
@initiator 使用者
@target 使用对象
@pall攻击管理器

*/
use:function(space, initiator, target, pall)
{
return Consunables.addHealth(initiator, 100);
}

}
var use=new ConsunablesUse(obj);
jobject.setUse(use);
