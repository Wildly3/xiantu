jobject.road=2;
jobject.name="易筋经[法术]";
jobject.icon=1;
jobject.explain="使用等级 1\n被动技能\n生命增加200，灵力增加100，防御增加20";
jobject.applylv=1;
jobject.usetype=1;
jobject.buy_price=1;
jobject.price=1;
var obj = {
/*
使用
@space 背包空间
@initiator 使用者
@target 使用对象
@pall攻击管理器

*/
use:function(space, initiator, target, pall)
{
	var flag = target.addSkill("易筋经");
	if(flag)
	pall.getEvent().Message("已获得技能 "+pall.getGood().name, 17);
	return flag;
}

}
var use=new ConsunablesUse(obj);
jobject.setUse(use);
