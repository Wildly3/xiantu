jobject.road=1;
jobject.name="爆弹";
jobject.icon=165;
jobject.explain="对敌人造成10点伤害，并眩晕3个回合！";
jobject.applylv=0;
jobject.buy_price=0;
jobject.price=0;
var obj = {

use:function(space, initiator, target, pall)
{
var buf=new Buffer();
	buf.name="眩晕";
	buf.type=Buffer.REDUCE;
	buf.attack_num = 1;
	buf.rounds=3;
	buf.setBaseBuffer(initiator);
	buf.setTargetBuffer(target);
	target.addBuffer(buf);
	pall.attack(10, initiator, target,
		"爆弹→"+target.name+"造成[atk]点伤害",
		Color.RED, AtkType.getInstance(hurt_consunables, 0);
	return true;
}

}
var use=new ConsunablesUse(obj);
jobject.setUse(use);