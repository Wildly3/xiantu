jobject.road=2;
jobject.name="暗冥丹";
jobject.explain="由极暗之地生长的暗冥草加之各种珍贵药材练成的丹药。\n永久增加生命[130]，永久增加攻击[35]，永久增加灵力[100]";
jobject.applylv=0;
jobject.buy_price=0;
jobject.price=0;
var obj = {
use:function(space, initiator, target, pall)
{
initiator.health+=130;
initiator.mp+=100;
initiator.atk+=35;
return true;
}
}
var use=new ConsunablesUse(obj);
jobject.setUse(use);
