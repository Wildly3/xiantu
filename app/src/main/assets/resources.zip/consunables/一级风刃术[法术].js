jobject.road=2;
jobject.icon=1;
jobject.name="一级风刃术[法术]";
jobject.explain="制造出风刃切割敌人，造成135%伤害";
jobject.applylv=2;
jobject.usetype=1;
jobject.buy_price=0;
jobject.price=0;
var obj = {
/*
使用
@space 背包空间
@initiator 使用者
@target 使用对象
@pall攻击管理器

*/
use:function(space, initiator, target, pall)
{
	var flag = target.addSkill("一级风刃术");
	if(flag)
	pall.getEvent().Message("已获得技能 "+pall.getGood().name, 17);
	return flag;
}

}

var use=new ConsunablesUse(obj);
jobject.setUse(use);
