jobject.road=0;
jobject.name="聚气丹";
jobject.icon=164;
jobject.explain="能快速的聚集灵力，恢复灵力20";
jobject.applylv=0;
jobject.buy_price=30;
jobject.price=10;
var obj = {
/*
使用
@space 背包空间
@initiator 使用者
@target 使用对象
@pall攻击管理器

*/
use:function(space, initiator, target, pall)
{
return Consunables.addMp(initiator, 20);
}

}
var use=new ConsunablesUse(obj);
jobject.setUse(use);
