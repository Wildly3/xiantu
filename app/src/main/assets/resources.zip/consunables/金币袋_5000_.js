jobject.road=2;
jobject.name="金币袋<5000>";
jobject.icon=19;
jobject.explain="使用后获得5000金币";
jobject.applylv=1;
jobject.usetype=1;
jobject.buy_price=0;
jobject.price=1;
var obj = {
/*
使用
@space 背包空间
@initiator 使用者
@target 使用对象
@pall攻击管理器

*/
use:function(space, initiator, target, pall)
{
var g = pall.getEvent();

var t="获得5000金币！";

g.addMoney(5000);

g.Message(t, 0);

return true;
}

}

var use=new ConsunablesUse(obj);
jobject.setUse(use);
