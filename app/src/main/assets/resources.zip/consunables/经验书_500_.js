jobject.road=2;
jobject.name="经验书<500>";
jobject.icon=166;
jobject.explain="使用后获得500经验！";
jobject.applylv=1;
jobject.usetype=1;
jobject.buy_price=0;
jobject.price=1;
var obj = {
/*
使用
@space 背包空间
@initiator 使用者
@target 使用对象
@pall攻击管理器

*/
use:function(space, initiator, target, pall)
{
var g = pall.getEvent();

var t="获得500经验！";

if(g.addExp(500))
t+="  升级！！！LV. "+g.getPlayLevel();

g.Message(t, 0);

return true;
}

}

var use=new ConsunablesUse(obj);
jobject.setUse(use);
