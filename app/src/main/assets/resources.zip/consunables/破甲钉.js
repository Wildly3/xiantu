jobject.road=1;
jobject.name="破甲钉";
jobject.explain="由精钢打造的飞钉，对敌人造成100%伤害并击破敌人护甲造成破甲状态(减少20%+15点防御)持续4回合。";
jobject.applylv=0;
jobject.buy_price=300;
jobject.price=200;
var obj = {
/*
使用
@space 背包空间
@initiator 使用者
@target 使用对象
@pall攻击管理器

*/
use:function(space, initiator, target, pall)
{
pall.attack(initiator.base.atk, initiator, target,
"破甲钉→"+target.name+"造成[atk]点伤害",
Color.RED, AtkType.getInstance(hurt_consunables, 0);

var buf=new Buffer();
buf.name="破甲";
buf.type=Buffer.REDUCE;
buf.def=(target.base.def*0.2)+15;
buf.rounds=4;
buf.setBaseBuffer(initiator);
buf.setTargetBuffer(target);
target.addBuffer(buf);
return true;
}
}
var use=new ConsunablesUse(obj);
jobject.setUse(use);
