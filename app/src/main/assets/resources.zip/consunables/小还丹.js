jobject.road=0;
jobject.name="小还丹";
jobject.icon=3;
jobject.explain="便宜又实惠的丹药，恢复[30]生命值";
jobject.applylv=0;
jobject.buy_price=30;
jobject.price=10;
var obj = {
/*
使用
@space 背包空间
@initiator 使用者
@target 使用对象
@pall攻击管理器

*/
use:function(space, initiator, target, pall)
{
return Consunables.addHealth(initiator, 30);
}

}
var use=new ConsunablesUse(obj);
jobject.setUse(use);
