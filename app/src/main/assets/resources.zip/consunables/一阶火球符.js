jobject.road=1;
jobject.name="一阶火球符";
jobject.icon=163;
jobject.explain="能施放出一阶的火球术对敌人造成巨大火属性伤害，10级以内几乎无人能挡！"
+"（攻击对象10级以下会忽略100%防御）";
jobject.applylv=0;
jobject.buy_price=650;
jobject.price=300;
var obj = {
use:function(space, initiator, target, pall)
{
var atk = 350;

if(target.level < 10) atk += target.base.def;

pall.attack(atk,
	initiator,
	target,
	"一阶火球术→"+target.name+"造成[atk]点伤害",
	Color.RED,
	AtkType.getInstance(hurt_consunables, 4));

return true;
}

}
var use=new ConsunablesUse(obj);
jobject.setUse(use);
