jobject.road=1;
jobject.name="一阶土盾符[秘制]";
jobject.icon=163;
jobject.explain="能施放出一阶土盾术（强化）加持自身持10级以内无人可伤！";
jobject.applylv=0;
jobject.buy_price=0;
jobject.price=0;
var obj = {
/*
使用
@space 背包空间
@initiator 使用者
@target 使用对象
@pall攻击管理器

*/
use:function(space, initiator, target, pall)
{
     initiator.base.addShield(1000);
					pall.SendMessage(initiator.name+"施放了[一阶土盾术.秘]", Color.rgb(199,97,20));
					return true;
}

}
var use=new ConsunablesUse(obj);
jobject.setUse(use);