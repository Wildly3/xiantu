jobject.road=2;
jobject.name="回城卷轴-新宿村";
jobject.icon=4;
jobject.explain="使用后回到新宿村";
jobject.applylv=1;
jobject.usetype=1;
jobject.buy_price=350;
jobject.price=150;
var obj = {

use:function(space, initiator, target, pall)
{
if(pall.getEvent().getNowMap()==1)
{
pall.getEvent().Message("位置 新宿村", 17);
return false;
}
pall.getEvent().MoveMap(1, 0, 0);
pall.getEvent().Message("位置 新宿村", 17);
return true;
}

}

var use=new ConsunablesUse(obj);
jobject.setUse(use);
