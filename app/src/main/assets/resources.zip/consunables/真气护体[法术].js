jobject.road=2;
jobject.name="真气护体[法术]";
jobject.icon=1;
jobject.explain="使用等级 1\n被动技能\n抵挡50%伤害每1点灵力抵挡2点伤害";
jobject.applylv=1;
jobject.usetype=1;
jobject.buy_price=1;
jobject.price=1;
var obj = {
/*
使用
@space 背包空间
@initiator 使用者
@target 使用对象
@pall攻击管理器

*/
use:function(space, initiator, target, pall)
{
	var flag = target.addSkill("真气护体");
	if(flag)
	pall.getEvent().Message("已获得技能 "+pall.getGood().name, 17);
	return flag;
}

}
var use=new ConsunablesUse(obj);
jobject.setUse(use);
