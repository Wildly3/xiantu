jobject.type=1;
jobject.consume_type=0;
jobject.name="暗冥斩";
jobject.explain="暗冥卫士的基本攻击技能，发出蕴含暗能量的一记斩击，对敌人造成115%伤害，附加10%当前灵力伤害";

var obj={
	//攻击前判断是否符合攻击条件
	Judge:function(sk, holder, enemy)
	{
		return holder.base.now_mp >= 30;
	},
	
	//攻击时
	attack:function(sk, holder, enemy)
	{
		var atk=toint((holder.base.atk * 1.15)+(holder.base.now_mp * 0.1));
		holder.base.now_mp -= 30;
		return atk;
	}
}

var ska=new SkillAttackAction(obj);
jobject.setAttack(ska);
