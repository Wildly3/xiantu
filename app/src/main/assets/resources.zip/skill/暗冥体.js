jobject.type=0;
jobject.consume_type=0;
jobject.name="暗冥体";
jobject.explain="<暗冥体质>\n每损失3%生命免疫1%伤害"+
"\n<狂暴>\n15%几率暴击（125%伤害）";
jobject.use_name=null;
jobject.health+=0;
jobject.atk+=0;
jobject.def+=0;
jobject.mp+=0;
var obj2={
	attack:function(atk, sk, holder, enemy, type){
	var pall=sk.getpall();
	var at=0.15;
	var atk2=atk*1.25;
	if(odds(at) & attacktype(type)==attack_commonly){
	 pall.SendMessage(holder.name+"暴击", Color.RED);
		return toint(atk2);
		}else
		return atk;
	},
	
	beingattacked:function(atk, sk, holder, enemy, type){
	    var ss=100-(enemy.getnowhealth()*100/enemy.getmaxhealth());
	    
	    if(ss < 3) return atk;
	    
	    var ss2=(ss/3)/100;
	    
	    var atk2=atk*ss2;
	    
	    var atk3=atk-atk2;
	    
					return toint(atk3);
	},
	
	onstartfight:function(holder, enes){
	},
	
	fightend:function(exp_m){
		return exp_m;
	},
	
	death:function(exp_m){
		return exp_m;
	}
}

var skp=new SkillPassiveAction(obj2);
jobject.setPassive(skp);
