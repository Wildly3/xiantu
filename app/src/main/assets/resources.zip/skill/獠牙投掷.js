jobject.type=2;
jobject.consume_type=2;
jobject.name="獠牙投掷";
jobject.explain="通过投掷野猪的獠牙进行攻击，每根獠牙造成40%攻击伤害，超过3根每根递减5%伤害最低5%伤害";
jobject.use_name="野猪獠牙";
jobject.health+=0;
jobject.atk+=0;
jobject.def+=0;
jobject.mp+=0;
var obj={
	//攻击前判断是否符合攻击条件
	Judge:function(sk, holder, enemy)
	{
		if(sk.SpeciFiedNumber()<1)return false;
		return true;
	},
	
	//攻击时
	attack:function(sk, holder, enemy)
	{
		var atkr=0.4;
					var atk=(holder.base.atk*atkr);
					if(sk.use_num>3){
						atk*=3;
						for(var i=0;i<sk.use_num-3;i++){
							atkr-=0.05;
							atk+=(holder.base.atk*atkr);
							if(atkr<(0.05))atkr=0.05;
						}
					}else atk=atk*sk.use_num;
					
					sk.space.takeout_material(
					sk.space.FindMaterial("野猪獠牙"),
					sk.use_num);
		return atk;

	}
}

var ska=new SkillAttackAction(obj);
jobject.setAttack(ska);
