jobject.type=1;
jobject.consume_type=0;
jobject.name="闪尾鞭";
jobject.explain="暗瞳蟒的基本攻击技能，速度极快的尾鞭，对敌人造成115%伤害";

var obj={
	//攻击前判断是否符合攻击条件
	Judge:function(sk, holder, enemy)
	{
		return holder.base.now_mp >= 18;
	},
	
	//攻击时
	attack:function(sk, holder, enemy)
	{
		holder.base.now_mp -= 18;
		return toint(holder.base.atk * 1.15);
	}
}

var ska=new SkillAttackAction(obj);
jobject.setAttack(ska);
