jobject.type=0;
jobject.consume_type=0;
jobject.name="真气护体";
jobject.explain="被动技能\n抵挡30%伤害由每1点灵力抵挡2点伤害";
jobject.use_name=null;

var obj2={
	attack:function(atk, sk, holder, enemy, type){
		
		return atk;
	},
	
	beingattacked:function(atk, sk, holder, enemy, type){
		if(enemy.base.now_mp<=0)return atk;
		
					if(atk<2)return atk;
					
					var atk2=(atk*0.3);
					
					var atk3=0.0;
					
					var usemp=atk2/2;
					
					if(enemy.base.now_mp<=usemp){
					
						var yu=usemp-enemy.base.now_mp;
						
						var yu_atk=yu*2;
						
						atk3=atk-(atk2-yu_atk);
						
						enemy.base.now_mp=0;
						
					}else {
						atk3=atk-atk2;
						enemy.base.now_mp-=usemp;
					}
					return toint(atk3);
	},
	
	onstartfight:function(holder, enes){
		
		
	},
	
	fightend:function(exp_m){
		
		return exp_m;
	},
	
	death:function(exp_m){
		
		return exp_m;
	}
}

var skp=new SkillPassiveAction(obj2);
jobject.setPassive(skp);
