jobject.type=0;
jobject.consume_type=0;
jobject.name="幽灵之身";
jobject.explain="<幽魂之力>\n受到攻击时会对攻击者造成侵蚀降低攻击力30";
jobject.use_name=null;
var obj2={
	attack:function(atk, sk, holder, enemy, type){
		return atk;
	},
	
	beingattacked:function(atk, sk, holder, enemy, type){
	if(type.equals("buffer"))
	return atk;
var buf=new Buffer();
buf.name="幽魂侵蚀";
buf.type=Buffer.REDUCE;
buf.atk=30;
buf.rounds=2;
addBuff(buf, enemy, holder);
return atk;
	},
	
	onstartfight:function(holder, enes){
	},
	
	fightend:function(exp_m){
		return exp_m;
	},
	
	death:function(exp_m){
		return exp_m;
	}
}

var skp=new SkillPassiveAction(obj2);
jobject.setPassive(skp);
