jobject.type=1;
jobject.consume_type=0;
jobject.name="野蛮冲撞";
jobject.explain="奋力冲撞一击，对敌方造成(等级*5+防御225%)伤害，并为自身增加(5+防御力50%)点护盾";
jobject.setCd(2);
var obj={
	//攻击前判断是否符合攻击条件
	Judge:function(sk, holder, enemy)
	{
		return holder.base.now_mp >= holder.base.def/2;
	},
	
	//攻击时
	attack:function(sk, holder, enemy)
	{
		holder.base.now_mp -= holder.base.def/2;
		
		holder.base.addShield(5+(holder.base.def/2));
		
		return toint((holder.level*5) + (holder.base.def * 2.25));
	}
}
var ska=new SkillAttackAction(obj);
jobject.setAttack(ska);
