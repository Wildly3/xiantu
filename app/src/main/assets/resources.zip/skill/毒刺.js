jobject.type=1;
jobject.consume_type=0;
jobject.name="毒刺";
jobject.explain="暗瞳蟒的基本攻击技能，地下生成毒刺攻击，对敌人造成100%伤害并造成中毒状态（灵力35%伤害）持续2回合";

var obj={
	//攻击前判断是否符合攻击条件
	Judge:function(sk, holder, enemy)
	{
		return holder.base.now_mp >= 25;
	},
	
	//攻击时
	attack:function(sk, holder, enemy)
	{
		holder.base.now_mp -= 25;
		setbuff_atk("暗瞳蟒毒", holder, enemy, toint(holder.base.max_mp*0.35), 2);
		return holder.base.atk;
	}
}

var ska=new SkillAttackAction(obj);
jobject.setAttack(ska);
