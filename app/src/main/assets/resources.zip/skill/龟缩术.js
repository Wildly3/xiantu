jobject.type=1;
jobject.consume_type=0;
jobject.name="龟缩术";
jobject.explain="老鳌的基本技能，身体进行龟缩2回合不能攻击，龟缩状态下防御增加8，并生成自身最大生命45%的护盾";

var obj={
	//攻击前判断是否符合攻击条件
	Judge:function(sk, holder, enemy)
	{
		return holder.base.now_mp >= 15;
	},
	
	//攻击时
	attack:function(sk, holder, enemy)
	{
	holder.base.setShield(holder.base.max_health * 0.45);
	
	var buf=new Buffer();
					buf.name="龟缩状态";
					buf.type=Buffer.REDUCE;
					buf.attack_num = 1;
					buf.rounds = 3;
					buf.setBaseBuffer(holder);
					buf.setTargetBuffer(holder);
					holder.addBuffer(buf);
					
					var buf=new Buffer();
					buf.name="龟甲防御";
					buf.type=Buffer.PROMOTE;
					buf.def = 8;
					buf.rounds = 3;
					buf.setBaseBuffer(holder);
					buf.setTargetBuffer(holder);
					holder.addBuffer(buf);
	
					sk.getpall().SendMessage(holder.name+"施放了[龟缩术]", Color.rgb(199,97,20));
		   holder.base.now_mp -= 15;
		return -1;
	}
}

var ska=new SkillAttackAction(obj);
jobject.setAttack(ska);
