jobject.type=1;
jobject.consume_type=0;
jobject.name="一级风刃术";
jobject.explain="制造出风刃切割敌人，造成100%攻击和40%速度加成点木属性伤害";
jobject.use_mp=5;
jobject.hurt_type=2;


var obj={
	//攻击前判断是否符合攻击条件
	Judge:function(sk, holder, enemy)
	{
		return holder.base.now_mp >= (holder.base.atk +((holder.base.speed * 0.4)/2))*0.1;
	},
	
	//攻击时
	attack:function(sk, holder, enemy)
	{
		holder.base.now_mp -= (holder.base.atk +((holder.base.speed * 0.4)/2))*0.1;
		return toint(holder.base.atk + (holder.base.speed*0.4));
	}
}

var ska=new SkillAttackAction(obj);
jobject.setAttack(ska);
