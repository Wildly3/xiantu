jobject.type=1;
jobject.consume_type=0;
jobject.name="暗冥护体";
jobject.explain="暗冥卫士的基本技能，展开暗冥之力形成保护罩（当前灵力115%），再次施放该技能会覆盖之前的护盾";
jobject.setCd(3);

var obj={
	//攻击前判断是否符合攻击条件
	Judge:function(sk, holder, enemy)
	{
		return holder.base.now_mp >= 40;
	},
	
	//攻击时
	attack:function(sk, holder, enemy)
	{
	holder.base.setShield(holder.base.now_mp * 1.15);
	/*
	var buf=new Buffer();
					buf.name="暗冥护体";
					buf.type=Buffer.PROMOTE;
					buf.def=toint(holder.base.now_mp * 0.36);
					buf.rounds=2;
					buf.setBaseBuffer(holder);
					buf.setTargetBuffer(holder);
					holder.addBuffer(buf);
					*/
					sk.getpall().SendMessage(holder.name+"施放了[暗冥护体]", Color.rgb(199,97,20));
		   holder.base.now_mp -= 40;
		return -1;
	}
}

var ska=new SkillAttackAction(obj);
jobject.setAttack(ska);
