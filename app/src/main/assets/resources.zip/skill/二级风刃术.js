jobject.type=1;
jobject.consume_type=0;
jobject.name="二级风刃术";
jobject.explain="制造出中型风刃切割敌人，相比一级风刃术威力可谓是巨大！造成110%攻击55%速度加成点木属性伤害";
jobject.use_mp=5;
jjobject.hurt_type=2;

var obj={
	//攻击前判断是否符合攻击条件
	Judge:function(sk, holder, enemy)
	{
		return holder.base.now_mp >= ((holder.base.atk*1.1) +((holder.base.speed * 0.55)/2))*0.1;
	},
	
	//攻击时
	attack:function(sk, holder, enemy)
	{
		holder.base.now_mp -= ((holder.base.atk*1.1) +((holder.base.speed * 0.55)/2))*0.1;
		return toint((holder.base.atk*1.1) + (holder.base.speed * 0.55));
	}
}

var ska=new SkillAttackAction(obj);
jobject.setAttack(ska);
