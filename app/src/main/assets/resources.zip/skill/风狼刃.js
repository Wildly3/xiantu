jobject.type=1;
jobject.consume_type=0;
jobject.name="风狼刃";
jobject.explain="风狼的一种基本法术，喷出风刃对敌人造成100%伤害附加50%速度伤害";

var obj={
	//攻击前判断是否符合攻击条件
	Judge:function(sk, holder, enemy)
	{
		return holder.base.now_mp >= (holder.base.atk +((holder.base.speed * 0.5)/2))*0.1;
	},
	
	//攻击时
	attack:function(sk, holder, enemy)
	{
		holder.base.now_mp -= (holder.base.atk +((holder.base.speed * 0.5)/2))*0.1;
		return toint(holder.base.atk + (holder.base.speed*0.5));
	}
}

var ska=new SkillAttackAction(obj);
jobject.setAttack(ska);
