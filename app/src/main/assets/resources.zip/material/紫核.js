jobject.name="紫核";
jobject.icon=17;
jobject.explain="紫影的生命核心，蕴含巨大能量！";
jobject.buy_price=0;
jobject.price=70;
