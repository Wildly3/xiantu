jobject.name="风狼皮毛";
jobject.icon=0;
jobject.explain="风狼的皮毛，非常适合制造上衣皮甲";
jobject.buy_price=0;
jobject.price=65;
