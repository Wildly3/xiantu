jobject.name="风狼晶核";
jobject.icon=15;
jobject.explain="风狼的晶核，具有风属性";
jobject.buy_price=0;
jobject.price=110;
