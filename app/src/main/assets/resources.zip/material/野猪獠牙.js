jobject.name="野猪獠牙";
jobject.icon=5;
jobject.explain="野猪的白色獠牙";
jobject.buy_price=0;
jobject.price=5;
