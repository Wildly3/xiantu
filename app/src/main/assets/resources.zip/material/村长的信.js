jobject.name="村长的信";
jobject.icon=24;
jobject.explain="天武，把那样东西给他吧！\n[村长的特殊印章]";
jobject.buy_price=0;
jobject.price=1;