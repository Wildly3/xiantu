jobject.name="野猪王的皮";
jobject.icon=0;
jobject.explain="野猪王的皮，非常的坚韧，一般用来制作衣服。";
jobject.buy_price=0;
jobject.price=45;
