jobject.name="影核";
jobject.icon=15;
jobject.explain="黑影的生命核心，非常的值钱！";
jobject.buy_price=0;
jobject.price=40;
