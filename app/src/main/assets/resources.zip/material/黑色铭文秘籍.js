jobject.name="黑色铭文秘籍";
jobject.icon=0;
jobject.explain="一本有些皱皱的秘籍，不惧水，上面印刻着一些看不懂的黑色铭文！";
jobject.buy_price=0;
jobject.price=1;
