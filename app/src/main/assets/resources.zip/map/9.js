//初始化地图信息
function onCreate()
{
var map = new MyMap(9);
map.name="转职殿";
map.afresh_map=1;
map.width=10;
map.height=10;

var item = new MapItem(9, 4,MyMap.MapItem.EXIT);
item.next_map=1;
item.name="新宿村";
item.next_map_pos_x=0;
item.next_map_pos_y=13;
map.addItem(item);


return map;
}

function onLoad()
{

}

var sw=0;

//选择事件
function Select(item, x, y)
{
var name = item.name;

return true;
}

//移动之前事件
function Movebfore(x, y)
{



}

//移动之后事件
function Moveafter(x, y)
{

}

//地图关闭事件
function onDestory()
{



}

//战斗结束
function Fightend(flag)
{


}
