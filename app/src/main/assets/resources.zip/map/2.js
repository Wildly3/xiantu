//初始化地图信息
function onCreate()
{
var map = new MyMap(2);
map.name="新宿村外-树林";
map.expainl="经常有野猪出没，适合LV 1-2级";
map.width=15;
map.height=15;
map.afresh_map=1;
map.encounter=0.1;
map.addEnemy("野猪");

var item = new MapItem(7,0,MyMap.MapItem.EXIT);
item.next_map=1;
item.name="新宿村";
item.next_map_pos_x=10;
item.next_map_pos_y=19;
map.addItem(item);

item = new MapItem(14, 3, MyMap.MapItem.BUILD);
item.name="池塘";
item.word="清澈见底的水下，还有些许鱼儿在游，水面上的荷叶随风浮动。";
item.color=Color.rgb(0, 200, 0);
map.addItem(item);

item = new MapItem(7,14,MyMap.MapItem.EXIT);
item.next_map=3;
item.name="新宿村南-河边";
item.setNextMapPosition(7, 0);
map.addItem(item);

item = new MapItem(3,10,MyMap.MapItem.GOODS);
item.name="木箱";
item.word="吱呀一声箱子打开";
item.addGoods(new MyMap.Goods("小还丹",Item.KIND_CONSUNABLES, 0, 10));
item.addGoods(new MyMap.Goods("獠牙投掷[法术]",Item.KIND_CONSUNABLES, 0, 1));
item.color=Color.YELLOW;
map.addItem(item);

	item = new MyMap.MapItem(MyMap.MapItem.ENEMY);
	item.name="强盗头目";
	item.word="小子那边不是你能去的地方！";
	item.addEnemy("强盗头目");
	item.addEnemy("强盗");
 item.addEnemy("强盗");
 item.addEnemy("强盗");
	item.CreatePointTigger(7,14);
	map.addItem(item);
	
	var item = new MapItem(14, 4,MyMap.MapItem.NPC_ORDINARY);
item.name="天武";
item.addSay("role", "看着池塘里的鱼儿尽情的游荡真好！");
item.addSay("role", "要是我也像鱼儿一样该多好啊！");
map.addItem(item);
	
	var item = new MapItem(0, 5,MyMap.MapItem.NPC_ORDINARY);
item.name="猎人";
item.addSay("role", "最近这里野猪很猖狂啊！");
item.addSay("role", "像我这么强的猎人都有点清理不过来了，嘿嘿。");
map.addItem(item);
	
	var item = new MapItem(0, 6,MyMap.MapItem.NPC_ORDINARY);
item.name="野猪王";
item.addSay("role", "哄哄哄！！！");
map.addItem(item);

	return map;
}

function onLoad()
{


}

//选择事件
function Select(item, x, y)
{
	if(item.id == 6 & get("tw_task") < 1)
	{
	dia1(item);
	return false;
	}
	else
	if(item.id==7)
	{
	var say = says();
	say.addsay(item.name, "给我[15]野猪獠牙我可以把我养的野猪王给你打，嘿嘿。");
	if(getgoodsnumber("野猪獠牙") >= 15){
	say.addsay(item.name, "确定要打吗？");
	say.end("fightyz");
	}
	else
	{
	say.addsay(item.name, "不过你的东西似乎不够啊。。。");
	}
	say.say();
	return false;
	}
	
	
	return true;
}

//挑战野猪王
function fightyz()
{
  _say("挑战", "是否挑战野猪王？", "fightyz2");
}

function fightyz2()
{
  takeoutgoods("野猪獠牙", 15);
  fight(new Array("野猪王"));
}

function dia1(item)
{
var play = getplayname();
var say = says();
if(getgoodsnumber("村长的信") < 1){
say.addsay(item.name, "听我一句。。最好别去河边！！！");
say.addsay(play, "为什么？");
say.addsay(item.name, "因为凭你现在的实力过去只有送死！");
say.addsay(play, "你有办法帮我过去吗？");
say.addsay(item.name, "有，嘿嘿，但是没有村长的许可我是不会帮你的。");
say.say();
}
else
{
say.addsay(play, "这是村长的信，这下你可以帮我了吧。");
say.addsay(item.name, "（怀疑的目光）。。。是吗？我看看。。。");
say.addsay(item.name, "（仔细查看中。。。）");
say.addsay(item.name, "。。是真的，好吧。。。。给你个符，别乱用啊！！");
say.end("get1");
say.say();
}
}

function get1()
{
put("tw_task", 1);
addconsunables("一阶土盾符[秘制]", 1);
say("提示", "获得 一阶土盾符[秘制]", 1);
}


//移动之前事件
function Movebfore(x, y)
{



}

//移动之后事件
function Moveafter(x, y)
{
	
	
}

//地图关闭事件
function onDestory()
{



}

//战斗结束
function Fightend(flag)
{



}
