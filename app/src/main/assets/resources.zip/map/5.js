//初始化地图信息
function onCreate()
{
	var map=new MyMap(5);
	map.name="采矿场";
	map.width=20;
	map.height=20;
	map.afresh_map=1;
	
	var item = new MapItem(1,19,MapItem.EXIT);
	item.next_map=4;
	
	item.name="土龙坡";
	item.setNextMapPosition(14,13);
	map.addItem(item);
	
	item = new MapItem(14,19,MapItem.BUILD);
	item.next_map=4;
	item.name="土龙坡";
	item.setNextMapPosition(1,2);
	map.encounter=0.15;
	map.addEnemy("矿洞幽灵");
	map.addEnemy("血魔");
	map.addItem(item);
	
	return map;
}

function onLoad()
{


}

//选择事件
function Select(item, x, y)
{
	
	return true;
}

//移动之前事件
function Movebfore(x, y)
{



}

//移动之后事件
function Moveafter(x, y)
{

}

//地图关闭事件
function onDestory()
{



}

//战斗结束
function Fightend(flag)
{



}
