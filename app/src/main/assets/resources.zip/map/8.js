//初始化地图信息
function onCreate()
{
var map = new MyMap(8);
map.name="试炼场";
map.afresh_map=1;
map.width=20;
map.height=20;

var item = new MapItem(0, 10,MyMap.MapItem.EXIT);
item.next_map=1;
item.name="新宿村";
item.next_map_pos_x=19;
item.next_map_pos_y=10;
map.addItem(item);

item = new MapItem(15, 13, MyMap.MapItem.BUILD);
item.name="暗冥卫士(挑战)";
item.word="";
item.color=Color.RED;
map.addItem(item);

item = new MapItem(15, 10, MyMap.MapItem.BUILD);
item.name="李云霄(挑战)";
item.color=Color.RED;
map.addItem(item);

return map;
}

function onLoad()
{

}

var sw=0;

//选择事件
function Select(item, x, y)
{
var name = item.name;
switch(item.id)
{
case 2:
fightsay("暗冥卫士", null, "fight_am");
sw=1;
return false;
case 3:
fightsay("李云霄", null, "fight_am");
sw=2;
break;
}

return true;
}

function fight_am()
{
switch(sw)
{
case 1:
testfight(new Array("暗冥卫士"));
break;
case 2:
testfight(new Array("李云霄"));
break;
}

}

//移动之前事件
function Movebfore(x, y)
{



}

//移动之后事件
function Moveafter(x, y)
{

}

//地图关闭事件
function onDestory()
{



}

//战斗结束
function Fightend()
{


}
