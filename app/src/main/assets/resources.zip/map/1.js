//初始化地图信息
function onCreate()
{
var map = new MyMap(1);
map.name="新宿村";
map.width=20;
map.height=20;

var item = new MapItem(5,0,MyMap.MapItem.NPC_ORDINARY);
item.name="村长";
item.addSay("role", "村外的野猪还真是猖獗呢！");

map.addItem(item);

item = new MapItem(12,6,MyMap.MapItem.NPC_SHOP_BUY);
item.name="王老板(杂货铺)";
item.addGoods(new Goods("青叶剑", Item.KIND_EQUIP));
item.addGoods(new Goods("生锈小铁剑", Item.KIND_EQUIP));
item.addGoods(new Goods("生锈大铁剑", Item.KIND_EQUIP));
item.addGoods(new Goods("铁剑", Item.KIND_EQUIP));
item.addGoods(new Goods("破败血刃", Item.KIND_EQUIP));
item.addGoods(new Goods("破损头箍", Item.KIND_EQUIP));
item.addGoods(new Goods("破损铜箍", Item.KIND_EQUIP));
item.addGoods(new Goods("破损银箍", Item.KIND_EQUIP));
item.addGoods(new Goods("金箍", Item.KIND_EQUIP));
item.addGoods(new Goods("青衫布衣", Item.KIND_EQUIP));
item.addGoods(new Goods("白衫布衣", Item.KIND_EQUIP));
item.addGoods(new Goods("灰布衣", Item.KIND_EQUIP));
item.addGoods(new Goods("木藤甲", Item.KIND_EQUIP));
item.addGoods(new Goods("破旧布鞋", Item.KIND_EQUIP));
item.addGoods(new Goods("青印鞋", Item.KIND_EQUIP));
item.addGoods(new Goods("蓝印鞋", Item.KIND_EQUIP));
item.addGoods(new Goods("白印鞋", Item.KIND_EQUIP));
item.addGoods(new Goods("金印鞋", Item.KIND_EQUIP));
item.addGoods(new Goods("魔法链", Item.KIND_EQUIP));
item.addGoods(new Goods("小还丹", Item.KIND_CONSUNABLES));
item.addGoods(new Goods("聚气丹", Item.KIND_CONSUNABLES));
item.addGoods(new Goods("灵泉水", Item.KIND_CONSUNABLES));
item.addGoods(new Goods("破甲钉", Item.KIND_CONSUNABLES));
item.addGoods(new Goods("回城卷轴-新宿村", Item.KIND_CONSUNABLES));
item.addGoods(new Goods("一阶火球符", Item.KIND_CONSUNABLES));
item.addGoods(new Goods("一阶土盾符", Item.KIND_CONSUNABLES));

map.addItem(item);

item = new MapItem(10,19,MyMap.MapItem.EXIT);
item.next_map=2;
item.name="新宿村外-树林";
item.setNextMapPosition(7,0);
map.addItem(item);

item = new MapItem(0,5,MyMap.MapItem.NPC_ORDINARY);
item.name="李云霄";
item.addSay("role", "树欲静而风不止。。。。");
item.color=Color.RED;
map.addItem(item);

item = new MapItem(0,0,MyMap.MapItem.REST);
item.name = "家"
map.addItem(item);

item = new MapItem(9,0,MyMap.MapItem.REPAIR);
item.name="装备修理处";
item.color=Color.RED;
map.addItem(item);

item = new MapItem(9,9,MyMap.MapItem.NPC_SHOP_SELL);
item.name="李记当铺";
item.color=Color.RED;
map.addItem(item);

item = new MapItem(19,1,MyMap.MapItem.EXIT);
item.next_map=6;
item.name="后山";
item.setNextMapPosition(1,1);
map.addItem(item);

item = new MapItem(19,10,MyMap.MapItem.EXIT);
item.next_map=8;
item.name="试炼场";
item.setNextMapPosition(0,10);
map.addItem(item);

item = new MapItem(0,13,MyMap.MapItem.EXIT);
item.next_map=9;
item.name="转职殿";
item.setNextMapPosition(9,4);
map.addItem(item);

return map;
}

function onLoad()
{

}

//选择事件
function Select(item, x, y)
{
var name = item.name;
switch(item.id)
{
case 1:
var task_name="驱赶野猪";
var isc=istask(task_name);
var is2=isaccepttask(task_name);
if(isc)
{
var say = says();
say.addsay(name, "又到了收成的季节咯。");
say.say();
return false;
}else
if(!is2)
{
var say = says();
say.addsay(name, "最近村子外的野猪越来越多了，菜地都被弄得乱七八糟的！");
say.end("task1");
say.say();
return false;
}


break;

case 4:
if(get("chen_first") < 1)
{
//say(name, say1, 1);
say1(name);

put("chen_first", 1);

return false;
}
break;

case 8:
if(getplaylevel() < 10)
{
message("等级过低，无法进入！", 0);
return false;
}
break;

}

return true;
}

//接取任务
function task1()
{
  var dia=new Dialog();
  dia.setTitle("提示");
  dia.setMessage("是否帮助村长驱赶野猪？");
  dia.setSelect("是", function(){
  addtask("驱赶野猪");
  message("已接取任务！", center);
  });
  dia.setCancel("否", null);
  dia.show();
}



//第一次见面
function say1(name)
{
var say = says();
say.addsay(name, "第一次见面，拿去。。。");
say.addsay(name, "（是一袋金币）");
say.addsay(getplayname(), "谢谢前辈，（总感觉前辈高深莫测）");
say.addsay(name, "我们还还会再见面的。");
say.end("say1_end");
say.say();
}

function say1_end()
{
addmoney(100);
say("提示", "获得100金币！", 1);
}

var bx=0, by=0;


//移动之前事件
function Movebfore(x, y)
{
bx=x;
by=y;
}


//移动之后事件
function Moveafter(x, y)
{
if(getplaylevel() < 10)
if(x==19 & y==1)
{
stopmove();
var say=says();
say.addsay(getplayname(), "那边很危险呢！以我现在的实力还是不要过去为好。");
say.end("move1");
say.say();
}

}

function move1()
{
moverole(bx, by);
}

//地图关闭事件
function onDestory()
{



}

//战斗结束
function Fightend()
{


}
