//初始化地图信息
function onCreate()
{
	var map=new MyMap(4);
	map.name="土龙坡";
	map.expainl="";
	map.width=20;
	map.height=20;
	map.afresh_map=1;
	
	var item = new MapItem(1,2,MapItem.EXIT);
	item.next_map=3;
	item.name="新宿村南-河边";
	item.setNextMapPosition(14,13);
	map.addItem(item);
	
	item = new MapItem(14,13,MapItem.EXIT);
	item.next_map=5;
	item.name="采矿场";
	item.setNextMapPosition(1,19);
	
	map.encounter=0.1;
	map.addEnemy("黑影");
	map.addEnemy("紫影");
	map.addItem(item);
	
	return map;
}

function onLoad()
{


}

//选择事件
function Select(item, x, y)
{
	
	return true;
}

//移动之前事件
function Movebfore(x, y)
{



}

//移动之后事件
function Moveafter(x, y)
{

}

//地图关闭事件
function onDestory()
{



}

//战斗结束
function Fightend(flag)
{



}
