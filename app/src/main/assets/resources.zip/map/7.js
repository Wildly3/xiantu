var hg="骸骨";
var hg_first="hg_first";

//初始化地图信息
function onCreate()
{
	var map=new MyMap(7);
	map.name="山洞";
	map.width=25;
	map.height=7;
	map.afresh_map=1;
		
	var item = new MapItem(1,3,MapItem.EXIT);
	item.next_map=6;
	item.name="后山";
	item.setNextMapPosition(14,3);
	map.addItem(item);
		
	item = new MapItem(3, 3, MapItem.BUILD);
	item.name=hg;
	item.word="一堆破烂的骸骨，死了很久了，这个地方很危险！";
	item.color=Color.rgb(180,180,180);
	map.addItem(item);
	map.addItem(item.NewItem(6, 6));
		
	item = new MapItem(24,4,MapItem.GOODS);
	item.name="金色宝箱";
	item.word="吱呀一声箱子打开";
	item.addGoods(new MyMap.Goods("暗冥丹",Item.KIND_CONSUNABLES, 0, 1));
	item.addGoods(new MyMap.Goods("暗冥刀",Item.KIND_EQUIP, Item.QUALITY_MEDIUM, 1));
	item.color=Color.YELLOW;
	map.addItem(item);
		
	item = new MapItem(MapItem.ENEMY);
	item.name="";
	item.word="误闯此地者杀！！！";
	item.addEnemy("暗冥卫士");
	item.CreatePointTigger(24,4);
	map.addItem(item);
	
	map.encounter=0.2;
	map.addEnemy("暗瞳蟒");
	return map;
}

function onLoad()
{


}

//选择事件
function Select(item, x, y)
{
	var name=item.name;
	if(name.equals(hg) & get(hg_first)==0)
	{
	put(hg_first, 1);
	var play=getplayname();
	var say=says();
	say.addsay(play, "看起来这已经是死了很久了。。。");
	say.addsay(play, "还是不要去了。。。");
	say.say();
	return false;
	}
	
	return true;
}

//移动之前事件
function Movebfore(x, y)
{



}

//移动之后事件
function Moveafter(x, y)
{

}

//地图关闭事件
function onDestory()
{



}

//战斗结束
function Fightend(flag)
{



}
