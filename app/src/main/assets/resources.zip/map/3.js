//初始化地图信息
function onCreate()
{
	var map=new MyMap(3);
	map.name="新宿村南-河边";
	map.width=15;
	map.height=15;
	map.afresh_map=1;
	
	var item=new MapItem(7,0,MapItem.EXIT);
	item.next_map=2;
	item.name="新宿村外-树林";
	item.setNextMapPosition(7,14);
	map.addItem(item);
		
	item = new MapItem(14,13,MapItem.EXIT);
	item.next_map=4;
	item.name="土龙坡";
	item.setNextMapPosition(1,2);
	map.addItem(item);
	
	var mi=new MapItem(0, 7, MapItem.BUILD);
	mi.color=Color.rgb(235,142,58);
	mi.name="河水";
	mi.word="奔腾的河水！";
		
map.AppendItems(MyMap.CreateBuilds(mi, 0, 6, 14, 6));

map.AppendItems(MyMap.CreateBuilds(mi, 0, 7, 7, 7));
	
item = new MapItem(8, 7, MapItem.GOODS);
item.name="包裹";
item.word="打开包裹~~~";
item.color=Color.rgb(235,142,58);
item.addGoods(new MyMap.Goods("黑色铭文秘籍",Item.KIND_MATERIAL, 0, 1));
item.addGoods(new MyMap.Goods("紫玉耳环",Item.KIND_EQUIP, 3));
map.addItem(item);

map.AppendItems(MyMap.CreateBuilds(mi, 9, 7, 14, 7));

	map.AppendItems(MyMap.CreateBuilds(mi, 0, 8, 14, 8));
	
	map.encounter=0.09;
	
	map.addEnemy("强盗头目");
	
	map.addEnemy("杀手");
		
	return map;
}

function onLoad()
{


}

var isll_fight = false;

var ffn="la_fight";

//选择事件
function Select(item, x, y)
{
	if(x == 8 && y == 7 && get(ffn) != 1){
	
	isll_fight = true;
	
	say("提示", "一只老鳌挡住了你！", 0);
	
	fight(new Array("老鳌"));
	
	return false;
	}
	
	return true;
}

//移动之前事件
function Movebfore(x, y)
{

}

//移动之后事件
function Moveafter(x, y)
{

}

//地图关闭事件
function onDestory()
{

}

//战斗结束
function Fightend(flag)
{
if(isll_fight && flag == 2){
put(ffn, 1);
}

isll_fight = false;
}
