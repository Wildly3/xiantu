//初始化地图信息
function onCreate()
{
	var map=new MyMap(6);
	map.name="后山";
	map.expainl="凶地！！！";
	map.width=30;
	map.height=30;
	map.afresh_map=1;
	
	var item = new MapItem(1,1,MapItem.EXIT);
	item.next_map=1;
	item.name="新宿村";
	item.setNextMapPosition(19,1)
	map.addItem(item);
	
	item = new MapItem(14,3,MapItem.EXIT);
	item.next_map=7;
	item.name="山洞";
	item.setNextMapPosition(1, 3);
	item.color=Color.RED;
	
	map.addItem(item);
	map.encounter=0.2;
	map.addEnemy("风狼");

	return map;
}

function onLoad()
{


}

//选择事件
function Select(item, x, y)
{
	
	return true;
}

//移动之前事件
function Movebfore(x, y)
{



}

//移动之后事件
function Moveafter(x, y)
{

}

//地图关闭事件
function onDestory()
{



}

//战斗结束
function Fightend(flag)
{



}
