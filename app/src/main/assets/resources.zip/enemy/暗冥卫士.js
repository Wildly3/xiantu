var chance=null;
jobject.name="暗冥卫士";
jobject.IncareaseLv(17);
jobject.appearodds=0.1;
jobject.appearodds_num=1;

jobject.WearSkill("暗冥体");
jobject.WearSkill("暗冥斩");
jobject.WearSkill("暗冥护体");
jobject.WearEquip("暗冥刀");
jobject.WearEquip("金刚箍");
jobject.WearEquip("暗冥铠甲");
jobject.WearEquip("天级金腕");