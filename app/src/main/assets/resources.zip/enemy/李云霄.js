jobject.name="李云霄";
jobject.health+=500;
jobject.IncareaseLv(64);
jobject.WearEquip("虚空剑");
jobject.WearEquip("天蚕软甲");