var chance=null;
jobject.name="暗瞳蟒";
jobject.health+=100;
jobject.IncareaseLv(14);
jobject.appearodds=0.1;
jobject.appearodds_num=1;
jobject.WearSkill("毒刺");
jobject.WearSkill("闪尾鞭");