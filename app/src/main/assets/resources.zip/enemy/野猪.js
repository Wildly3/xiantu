var chance=null;
jobject.name="野猪";
jobject.appearodds=0.2;
jobject.appearodds_num=1;
chance=new Chance("野猪獠牙",2);
chance.chance=1.0;
chance.quanlity_low=1;
chance.quanlity_hight=2;
jobject.addGod(chance);
