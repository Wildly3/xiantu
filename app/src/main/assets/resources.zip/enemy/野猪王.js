var chance=null;
jobject.name="野猪王";
jobject.health+=30;
jobject.atk+=5;
jobject.def+=6;
jobject.mp+=0;
jobject.speed-=5;
jobject.IncareaseLv(2);
jobject.appearodds=0;
jobject.appearodds_num=1;
jobject.WearEquip("獠牙长矛");
jobject.WearSkill("野蛮冲撞");

chance=new Chance("獠牙长矛",0);
chance.chance=0.1;
chance.quanlity_low=1;
chance.quanlity_hight=1;
jobject.addGod(chance);

chance=new Chance("野猪王的皮",2);
chance.chance=0.15;
chance.quanlity_low=1;
chance.quanlity_hight=1;
jobject.addGod(chance);