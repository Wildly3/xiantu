var chance=null;
jobject.name="风狼";
jobject.speed+=45;
jobject.atk+=10;
jobject.IncareaseLv(11);
jobject.appearodds=0.2;
jobject.appearodds_num=1;
jobject.WearSkill("风狼刃");

chance=new Chance("风狼皮毛",2);
chance.chance=0.25;
chance.quanlity_low=1;
chance.quanlity_hight=1;
jobject.addGod(chance);

chance=new Chance("风狼晶核",2);
chance.chance=0.1;
chance.quanlity_low=1;
chance.quanlity_hight=1;
jobject.addGod(chance);
