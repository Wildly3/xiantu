jobject.name="老鳌";
jobject.health+=38;
jobject.atk+=7;
jobject.def+=8;
jobject.speed-=7;
jobject.IncareaseLv(3);
jobject.WearSkill("龟缩术");