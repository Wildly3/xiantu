jobject.type=6;
jobject.name="金印鞋";
jobject.explain2="有金色印纹的鞋子";
jobject.applylv=9;
jobject.attrauto();