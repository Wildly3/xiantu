jobject.type=4;
jobject.name="青衫布衣";
jobject.explain2="略显单薄的衣服";
jobject.applylv=3;
jobject.attrauto();