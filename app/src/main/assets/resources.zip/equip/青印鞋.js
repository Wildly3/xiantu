jobject.type=6;
jobject.name="青印鞋";
jobject.explain2="有青色印纹的鞋子";
jobject.applylv=2;
jobject.attrauto();