jobject.type=4;
jobject.name="木藤甲";
jobject.icon=137;
jobject.explain2="木质藤甲，防御力较高";
jobject.applylv=9;
jobject.health+=5;
jobject.def+=10;
jobject.attrauto();