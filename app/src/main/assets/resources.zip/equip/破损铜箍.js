jobject.type=1;
jobject.name="破损铜箍";
jobject.explain2="铜制的破损头箍";
jobject.applylv=4;
jobject.def+=1;
jobject.attrauto();