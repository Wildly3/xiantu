jobject.type=0;
jobject.name="嗜血铁爪";
jobject.explain2="血魔:啊~~血啊\n<嗜血>\n攻击时有35%几率吸取伤害30%的生命值";
jobject.applylv=11;
jobject.attrauto();
//效果接口
var obj = {
/*
战斗开始时
@holder 自己
@enes 敌人列表
*/
onstartfight:function(holder, enes)
{

},
/*
战斗结束时
@exp_m 经验
*/
fightend:function(exp_m)
{
     return exp_m;
},
/*
死亡时
@exp_m 经验

*/
death:function(exp_m)
{
     return exp_m;
},
/*
被攻击时
@atk 攻击力
@holder 攻击者
@enemy 被攻击者
@pall 攻击管理器
*/
beattack:function(atk, holder, enemy, pall, type)
{
     return atk;
},
/*
攻击时
@atk 攻击力
@holder 攻击者
@enemy 被攻击者
@pall 攻击管理器
*/
attack:function(atk, holder, enemy, pall, type)
{
					if(odds(0.35)){
					var atk1=pall.getAAtk();
						var ax=(atk1*0.3);
						ax=(ax<=0 ? 1 : ax);
						pall.SendMessage(holder.name+"触发[嗜血]效果吸取["+toint(ax)+"]点生命",Color.BLUE);
						if(ax<=(holder.base.max_health-holder.base.now_health)){
							holder.base.now_health+=ax;
						}else holder.base.now_health=holder.base.max_health;
					}
     return atk;
}
}
var buff=new BeBuffer(obj);
jobject.setBeBuff(buff);
