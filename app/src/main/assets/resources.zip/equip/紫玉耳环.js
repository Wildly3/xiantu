jobject.type=2;
jobject.name="紫玉耳环";
jobject.explain2="紫色玉石打造的小巧耳环~~~\n上面似乎印刻这一个 冥 字。";
jobject.applylv=3;
jobject.mp+=30;
jobject.attrauto();