jobject.type=3;
jobject.name="魔法链";
jobject.explain2="获得经验加成10%";
jobject.applylv=5;
jobject.health+=50;
jobject.attrauto();
jobject.buy_price+=500;

//效果接口
var obj = {
/*
战斗开始时
@holder 自己
@enes 敌人列表
*/
onstartfight:function(holder, enes)
{

},
/*
战斗结束时
@exp_m 经验
*/
fightend:function(exp_m)
{
exp_m[0]=toint((exp_m[0]*1.10));
     return exp_m;
},
/*
死亡时
@exp_m 经验

*/
death:function(exp_m)
{
     return exp_m;
},
/*
被攻击时
@atk 攻击力
@holder 攻击者
@enemy 被攻击者
@pall 攻击管理器
*/
beattack:function(atk, holder, enemy, pall, type)
{
     return atk;
},
/*
攻击时
@atk 攻击力
@holder 攻击者
@enemy 被攻击者
@pall 攻击管理器
*/
attack:function(atk, holder, enemy, pall, type)
{
     return atk;
}
}
var buff=new BeBuffer(obj);
jobject.setBeBuff(buff);
