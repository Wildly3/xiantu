jobject.type=1;
jobject.name="破损头箍";
jobject.explain2="破烂般的一个铁圈，还要戴在头上。。";
jobject.applylv=2;
jobject.def+=1;
jobject.attrauto();