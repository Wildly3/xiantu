jobject.type=3;
jobject.name="黑龙项链";
jobject.explain2="黑龙筋制成的项链"
+"\n<黑龙护>\n被攻击时生命值少于30%会获得最大生命值35%的护盾，该效果只会触发一次，并且战斗开始生命值小于30%这个效果也不会触发！"
jobject.applylv=10;
jobject.health+=150;
jobject.attrauto();
jobject.buy_price+=500;

//效果接口
var obj = {
/*
战斗开始时
@holder 自己
@enes 敌人列表
*/
onstartfight:function(holder, enes)
{
     var hp=holder.base.now_health;
     var mhp=holder.base.max_health;
     var at=(hp/mhp)*100;
     if(at < 30)
     {
         holder.getAll().put("hlh_xl", 1);
     }
      
},
/*
战斗结束时
@exp_m 经验
*/
fightend:function(exp_m)
{
     return exp_m;
},
/*
死亡时
@exp_m 经验

*/
death:function(exp_m)
{
     return exp_m;
},
/*
被攻击时
@atk 攻击力
@holder 攻击者
@enemy 被攻击者
@pall 攻击管理器
*/
beattack:function(atk, holder, enemy, pall, type)
{
     var hp=enemy.base.now_health;
     var mhp=enemy.base.max_health;
     var at=(hp/mhp)*100;
     var cn=pall.getInt("hlh_xl");
     if(at < 30 & cn == 0)
     {
         pall.put("hlh_xl", 1);
         enemy.base.addShield(toint(mhp*0.35));
     }
     
     return atk;
},
/*
攻击时
@atk 攻击力
@holder 攻击者
@enemy 被攻击者
@pall 攻击管理器
*/
attack:function(atk, holder, enemy, pall, type)
{
     return atk;
}
}
var buff=new BeBuffer(obj);
jobject.setBeBuff(buff);
