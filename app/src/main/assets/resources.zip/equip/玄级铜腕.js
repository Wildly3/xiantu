jobject.type=5;
jobject.name="玄级铜腕";
jobject.explain2="杀手等级玄级的标志！\n<玄级压制>\n攻击时附带(45+(LV*0.5))点伤害";
jobject.applylv=18;
jobject.attrauto();
//效果接口
var obj = {
/*
战斗开始时
@holder 自己
@enes 敌人列表
*/
onstartfight:function(holder, enes)
{

},
/*
战斗结束时
@exp_m 经验
*/
fightend:function(exp_m)
{
     return exp_m;
},
/*
死亡时
@exp_m 经验

*/
death:function(exp_m)
{
     return exp_m;
},
/*
被攻击时
@atk 攻击力
@holder 攻击者
@enemy 被攻击者
@pall 攻击管理器
*/
beattack:function(atk, holder, enemy, pall, type)
{
     return atk;
},
/*
攻击时
@atk 攻击力
@holder 攻击者
@enemy 被攻击者
@pall 攻击管理器
*/
attack:function(atk, holder, enemy, pall, type)
{
atk+=(45+(holder.level*0.5));
					if(atk<1)atk=1;
     return atk;
}
}
var buff=new BeBuffer(obj);
jobject.setBeBuff(buff);
