jobject.type=1;
jobject.name="金箍";
jobject.explain2="黄金打造的头箍";
jobject.applylv=8;
jobject.def+=2;
jobject.attrauto();