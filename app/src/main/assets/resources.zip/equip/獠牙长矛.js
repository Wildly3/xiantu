jobject.type=0;
jobject.name="獠牙长矛";
jobject.explain2="用野猪王的獠牙打造，极其尖锐，攻击力强！\n"+
"\n<威慑>\n长矛存在野猪王的气息，威慑敌人，自身等级高于或者等于对方等级 附加3+(LV*1.0)点伤害";
jobject.applylv=2;
jobject.attrauto();
//效果接口
var obj = {
/*
战斗开始时
@holder 自己
@enes 敌人列表
*/
onstartfight:function(holder, enes)
{
},
/*
战斗结束时
@exp_m 经验
*/
fightend:function(exp_m)
{
     return exp_m;
},
/*
死亡时
@exp_m 经验

*/
death:function(exp_m)
{
     return exp_m;
},
/*
被攻击时
@atk 攻击力
@holder 攻击者
@enemy 被攻击者
@pall 攻击管理器
*/
beattack:function(atk, holder, enemy, pall, type)
{
     return atk;
},
/*
攻击时
@atk 攻击力
@holder 攻击者
@enemy 被攻击者
@pall 攻击管理器
*/
attack:function(atk, holder, enemy, pall, type)
{
     if(holder.level >= enemy.level)
     atk+=3+(holder.level);
     
     return atk;
}
}
var buff=new BeBuffer(obj);
jobject.setBeBuff(buff);
