jobject.type=0;
jobject.name="青铜短匕";
jobject.explain2="杀手的专用武器\n<致命>\n攻击生命值小于50%的敌人时有50%几率附加已损失生命值16%伤害，对方等级超过自身等级这个附加伤害将会减半";
jobject.applylv=4;
jobject.attrauto();
//效果接口
var obj = {
/*
战斗开始时
@holder 自己
@enes 敌人列表
*/
onstartfight:function(holder, enes)
{

},
/*
战斗结束时
@exp_m 经验
*/
fightend:function(exp_m)
{
     return exp_m;
},
/*
死亡时
@exp_m 经验

*/
death:function(exp_m)
{
     return exp_m;
},
/*
被攻击时
@atk 攻击力
@holder 攻击者
@enemy 被攻击者
@pall 攻击管理器
*/
beattack:function(atk, holder, enemy, pall, type)
{
     return atk;
},
/*
攻击时
@atk 攻击力
@holder 攻击者
@enemy 被攻击者
@pall 攻击管理器
*/
attack:function(atk, holder, enemy, pall, type)
{
					if(odds(0.5)&enemy.base.now_health<(enemy.base.max_health/2)){
						pall.SendMessage(holder.name+"触发[致命]效果",Color.BLUE);
						var atk2=toint((enemy.base.max_health-enemy.base.now_health)*0.16);
						if(holder.level < enemy.level)
						atk2/=2;
						atk+=atk2;
					}
     return atk;
}
}
var buff=new BeBuffer(obj);
jobject.setBeBuff(buff);
