jobject.type=4;
jobject.name="荆棘铠甲";
jobject.icon=169;
jobject.explain2="布满荆棘的铠甲，具有极强的防御力！\n<反伤>\n被普通攻击时反弹20%伤害（每10点防御该伤害加成提升1%，反弹伤害为计算防御之前）";
jobject.applylv=10;
jobject.def+=10;
jobject.attrauto();

var flag = "attack_jjkj<FILTRATION_MY><FILTRATION_ACCURATE>";

//效果接口
var obj = {

onstartfight:function(holder, enes)
{

},

fightend:function(exp_m)
{
     return exp_m;
},

death:function(exp_m)
{
     return exp_m;
},

beattack:function(atk, holder, enemy, pall, type)
{
	if(attacktype(type) != attack_commonly) return atk;
	var hurt = 0.2;
	hurt += ((enemy.base.def/10)*0.01);
	pall.attack(toint(pall.getBAtk()*hurt),
		enemy,
		holder,
		holder.name+"受到"+enemy.name+"反弹[atk]点伤害",
		Color.RED,
		AtkType.getInstance(flag, 0));
					
     return atk;
},

attack:function(atk, holder, enemy, pall, type)
{
     return atk;
}
}
var buff=new BeBuffer(obj);
jobject.setBeBuff(buff);
