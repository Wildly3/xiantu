jobject.type=0;
jobject.name="青叶剑";
jobject.icon=50;
jobject.explain2="翠绿的剑柄，剑身刚硬！\n<青芒>\n普通攻击两次后任何攻击附带木属性伤害20+（LV*1）";
jobject.applylv=5;
jobject.health+=10;
jobject.atk+=5;
jobject.wood=5;
jobject.attrauto();
jobject.buy_price+=800;

var flag="qyj_qm";

//效果接口
var obj = {
/*
战斗开始时
@holder 自己
@enes 敌人列表
*/
onstartfight:function(holder, enes)
{

},
/*
战斗结束时
@exp_m 经验
*/
fightend:function(exp_m)
{
     return exp_m;
},
/*
死亡时
@exp_m 经验

*/
death:function(exp_m)
{
     return exp_m;
},
/*
被攻击时
@atk 攻击力
@holder 攻击者
@enemy 被攻击者
@pall 攻击管理器
*/
beattack:function(atk, holder, enemy, pall, type)
{
     return atk;
},
/*
攻击时
@atk 攻击力
@holder 攻击者
@enemy 被攻击者
@pall 攻击管理器
*/
attack:function(atk, holder, enemy, pall, type)
{
 var count = pall.getInt(flag);
 
 if(type.equals(flag))
 return atk;
 
 if(count > 1)
 {
 pall.put(flag, 0);
 pall.attack(20+holder.level, holder, enemy,
"青芒→"+enemy.name+"造成[atk]点伤害",
Color.GREEN, AtkType.getInstance(flag, 2));
return atk;
 }
 
 if(attacktype(type) == attack_commonly)
 {
   pall.put(flag, ++count);
 }
     return atk;
}
}
var buff=new BeBuffer(obj);
jobject.setBeBuff(buff);
