jobject.type=0;
jobject.name="生锈小铁剑";
jobject.icon=47;
jobject.explain2="泛黄锈迹的小铁剑";
jobject.applylv=1;
jobject.attrauto();