jobject.type=0;
jobject.name="暗冥刀";
jobject.explain2=
"乌黑的长刀，寒气逼人！由极暗之地开采而出的暗冥铁打造而成，蕴含极暗之力，同时附带了大量的冥气\n"+
"<暗>\n战斗开始时被极暗之力保护，增加30+(75%攻击力)点护盾\n<冥>\n攻击时附带冥气(增加10%伤害)";
jobject.applylv=18;
jobject.atk+=60;
jobject.mp+=100;
jobject.attrauto();

//效果接口
var obj = {

onstartfight:function(holder, enes)
{
	holder.base.setShield(30+(holder.base.atk*0.75));
},

fightend:function(exp_m)
{
     return exp_m;
},

death:function(exp_m)
{
     return exp_m;
},

beattack:function(atk, holder, enemy, pall, type)
{
     return atk;
},

attack:function(atk, holder, enemy, pall, type)
{
	atk+=toint(pall.getBAtk()*0.1);
	return atk;
}
}
var buff=new BeBuffer(obj);
jobject.setBeBuff(buff);
