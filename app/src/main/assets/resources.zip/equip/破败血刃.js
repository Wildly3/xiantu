jobject.type=0;
jobject.name="破败血刃";
jobject.explain2="血色的弯刃\n<破败>\n攻击时有30%几率对敌人附加破败效果(25%攻击力+敌人最大生命值8%伤害)，持续3回合，战斗开始时对所有敌人附加破败效果，持续1回合";
jobject.applylv=12;
jobject.health+=30;
jobject.attrauto();
jobject.buy_price+=1500;
//效果接口
var obj = {
/*
战斗开始时
@holder 自己
@enes 敌人列表
*/
onstartfight:function(holder, enes)
{
	for(var i=0;i<enes.size();i++){
	var p=enes.get(i);
	var batk=(holder.base.atk*0.25)+(p.base.max_health*0.08);
	setbuff_atk("破败", holder, p, batk, 1);
	}
},
/*
战斗结束时
@exp_m 经验
*/
fightend:function(exp_m)
{
     return exp_m;
},
/*
死亡时
@exp_m 经验

*/
death:function(exp_m)
{
     return exp_m;
},
/*
被攻击时
@atk 攻击力
@holder 攻击者
@enemy 被攻击者
@pall 攻击管理器
*/
beattack:function(atk, holder, enemy, pall, type)
{
     return atk;
},
/*
攻击时
@atk 攻击力
@holder 攻击者
@enemy 被攻击者
@pall 攻击管理器
*/
attack:function(atk, holder, enemy, pall, type)
{
if(attacktype(pall) != attack_commonly) return atk;
					if(odds(0.3)){
						pall.SendMessage(holder.name+"触发[破败]效果",Color.RED);
						var batk=(holder.base.atk*0.25)+(enemy.base.max_health*0.08);
						setbuff_atk("破败", holder, enemy, batk, 3);
					}
     return atk;
}
}
var buff=new BeBuffer(obj);
jobject.setBeBuff(buff);
