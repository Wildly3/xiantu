jobject.type=4;
jobject.name="灰布衣";
jobject.explain2="质量较好的衣服";
jobject.applylv=6;
jobject.health+=6;
jobject.attrauto();