jobject.type=0;
jobject.name="铁剑";
jobject.icon=49;
jobject.explain2="普通的一把铁剑";
jobject.applylv=6;
jobject.attrauto();