jobject.type=0;
jobject.name="虚空剑";
jobject.explain2="使用虚空材料炼制的长剑，具有虚空神通，杀人于无形！"
+"\n<虚空>\n虚空神通，战斗开始增加速度150点持续15回合"
+"\n<破碎>\n虚空属性，无视30%防御";
jobject.applylv=65;
jobject.atk+=300;
jobject.mp+=500;
jobject.attrauto();

//效果接口
var obj = {
/*
战斗开始时
@holder 自己
@enes 敌人列表
*/
onstartfight:function(holder, enes)
{
var buf=new Buffer();
buf.name="虚空";
buf.type=Buffer.PROMOTE;
buf.setRounds(15);
buf.speed=150;
addBuff(buf, holder, holder);
},
/*
战斗结束时
@exp_m 经验
*/
fightend:function(exp_m)
{
     return exp_m;
},
/*
死亡时
@exp_m 经验

*/
death:function(exp_m)
{
     return exp_m;
},
/*
被攻击时
@atk 攻击力
@holder 攻击者
@enemy 被攻击者
@pall 攻击管理器
*/
beattack:function(atk, holder, enemy, pall, type)
{
     return atk;
},
/*
攻击时
@atk 攻击力
@holder 攻击者
@enemy 被攻击者
@pall 攻击管理器
*/
attack:function(atk, holder, enemy, pall, type)
{
    atk+=toint(enemy.base.def*0.3);
     return atk;
}
}

var buff=new BeBuffer(obj);
jobject.setBeBuff(buff);