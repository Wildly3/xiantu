jobject.type=4;
jobject.name="白衫布衣";
jobject.explain2="略显单薄的衣服";
jobject.applylv=4;
jobject.health+=5;
jobject.attrauto();