jobject.type=6;
jobject.name="破旧布鞋";
jobject.explain2="露出脚趾的破旧布鞋";
jobject.applylv=1;
jobject.attrauto();