jobject.type=6;
jobject.name="蓝印鞋";
jobject.explain2="有蓝色印纹的鞋子";
jobject.applylv=4;
jobject.attrauto();