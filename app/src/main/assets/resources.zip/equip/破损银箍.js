jobject.type=1;
jobject.name="破损银箍";
jobject.explain2="银制的破损头箍";
jobject.applylv=6;
jobject.def+=1;
jobject.attrauto();