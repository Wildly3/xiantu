jobject.type=4;
jobject.name="幽灵白袍";
jobject.explain2="矿洞幽灵：呜呜~呜~我的白袍去哪了？？\n<虚化>\n被攻击时有25%几率虚化避免15%的伤害";
jobject.applylv=10;
jobject.attrauto();
//效果接口
var obj = {
/*
战斗开始时
@holder 自己
@enes 敌人列表
*/
onstartfight:function(holder, enes)
{

},
/*
战斗结束时
@exp_m 经验
*/
fightend:function(exp_m)
{
     return exp_m;
},
/*
死亡时
@exp_m 经验

*/
death:function(exp_m)
{
     return exp_m;
},
/*
被攻击时
@atk 攻击力
@holder 攻击者
@enemy 被攻击者
@pall 攻击管理器
*/
beattack:function(atk, holder, enemy, pall, type)
{
					if(odds(0.25)){
						var xg=toint((atk*0.15));
						if(xg>0){
						pall.SendMessage(enemy.name+"触发[虚化]避免["+xg+"]点伤害", Color.GREEN);
						atk-=xg; }
						}
						if(atk<1)atk=1;
     return atk;
},
/*
攻击时
@atk 攻击力
@holder 攻击者
@enemy 被攻击者
@pall 攻击管理器
*/
attack:function(atk, holder, enemy, pall, type)
{
     return atk;
}
}
var buff=new BeBuffer(obj);
jobject.setBeBuff(buff);
