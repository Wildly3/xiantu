jobject.type=0;
jobject.name="生锈大铁剑";
jobject.icon=48;
jobject.explain2="泛黄锈迹的大铁剑";
jobject.applylv=3;
jobject.attrauto();