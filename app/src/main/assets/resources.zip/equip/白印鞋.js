jobject.type=6;
jobject.name="白印鞋";
jobject.explain2="有白色印纹的鞋子";
jobject.applylv=6;
jobject.attrauto();