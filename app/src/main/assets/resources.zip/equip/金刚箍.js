jobject.type=1;
jobject.name="金刚箍";
jobject.explain2="精钢打造的头箍，泛着金色的光泽\n<金刚不坏>\n被攻击时有25%几率触发金刚不坏(增加防御20)持续6回合";
jobject.applylv=18;
jobject.health+=100;
jobject.attrauto();

//效果接口
var obj = {
/*
战斗开始时
@holder 自己
@enes 敌人列表
*/
onstartfight:function(holder, enes)
{

},
/*
战斗结束时
@exp_m 经验
*/
fightend:function(exp_m)
{
     return exp_m;
},
/*
死亡时
@exp_m 经验

*/
death:function(exp_m)
{
     return exp_m;
},
/*
被攻击时
@atk 攻击力
@holder 攻击者
@enemy 被攻击者
@pall 攻击管理器
*/
beattack:function(atk, holder, enemy, pall, type)
{
if(odds(0.25)){
setbuff_def("金刚不坏", enemy, enemy, 20, 6);
pall.SendMessage(enemy.name+"触发[金刚不坏]效果",Color.YELLOW);
}
     return atk;
},
/*
攻击时
@atk 攻击力
@holder 攻击者
@enemy 被攻击者
@pall 攻击管理器
*/
attack:function(atk, holder, enemy, pall, type)
{
     return atk;
}
}
var buff=new BeBuffer(obj);
jobject.setBeBuff(buff);
